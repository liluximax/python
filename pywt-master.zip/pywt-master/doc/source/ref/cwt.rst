.. _ref-cwt:

.. currentmodule:: pywt

=================================
Continous Wavelet Transform (CWT)
=================================

This section describes functions used to perform single continous wavelet
transforms.

Single level - ``cwt``
----------------------

.. autofunction:: cwt



